-- This should be run in Supabase SQL Editor
-- Or you can do this through the Supabase Dashboard:
-- Go to Authentication > Settings > Email Auth
-- Turn OFF "Enable email confirmations"

-- Update auth settings (if you have access to these tables)
-- Note: These settings are usually managed through the Supabase Dashboard
-- Go to: Authentication > Settings > Email Auth > Enable email confirmations = OFF
